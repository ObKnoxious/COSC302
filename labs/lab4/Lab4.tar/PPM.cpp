//#include <fstream>
//using namespace std;

//#include "PPM.h"
//#include <string.h>
//#include <iostream>
//void PPM::read(string fn) { 
	//ifstream fin;
	//fin.open(fn.c_str());
	//string h;
	////unsigned char rw;
	////unsigned char cl;
	////unsigned char mx;
	//int rw;
	//int cl;
	//int mx;
	//fin >> h >> rw >> cl >> mx;
	//cout << h << '\t' << rw << '\t' << cl << '\t' << mx << '\n';
	//head =h;
	//rows =rw;
	//columns =cl;
	//maxi = mx;
	//fin.close();	
	
//}

//void PPM::write(string fn) { 
  ////write this
//}


//int main(int argc, char *argv[]){
	//PPM myimg;;
	//myimg.read(argv[1]);
	//return 0;

//}
